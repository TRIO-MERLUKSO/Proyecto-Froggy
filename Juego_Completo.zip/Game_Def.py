# Froggy game
import pygame


# CONFIGURACIÓN DE PANTALLA



def pantalla():
    return pygame.display.set_mode([800, 800])

def color():
    return {
        "BLANCO":   (255,255,255),
        "MORADO":   (142,68,173),
        "VERDE":    (22,163,133),
        "GRIS":     (200,200,200),
        "AZUL":     (0,0,255),
        "ROJO":     (255,0,0),
        "NARANJA":  (255,128,0),
        "NEGRO":    (0,0,0),
        "AMARILLO": (255,255,0)
    }


# MENÚ

def opcion(teclas, opcion):
    if teclas[pygame.K_w] or teclas[pygame.K_UP]:
        opcion -= 1
    if teclas[pygame.K_s] or teclas[pygame.K_DOWN]:
        opcion += 1

    if opcion > 3:
        opcion = 0
    if opcion < 0:
        opcion = 3
    return opcion

def boton(screen, fuente, c, texto, x, y, ancho, alto, seleccionado):
    pygame.draw.rect(screen, c["ROJO"] if seleccionado else c["BLANCO"], (x,y,ancho,alto))
    label = fuente.render(texto, True, c["NEGRO"])
    screen.blit(label, (x + ancho//2 - label.get_width()//2, y + alto//2 - label.get_height()//2))

def menu():
    pygame.init()
    pygame.mixer.init()
    pygame.display.set_caption("Crossy Road")

    cancionmenu = pygame.mixer.Sound('musica_menu.wav')
    cancionmenu.play(-1)

    screen = pantalla()
    c = color()
    fuente = pygame.font.SysFont(None, 40)
    opcion_actual = 0
    seguir = True
    enter_presionado = False

    while seguir:
        pygame.time.delay(120)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return 3

        tecla = pygame.key.get_pressed()
        opcion_actual = opcion(tecla, opcion_actual)

        if tecla[pygame.K_RETURN] and not enter_presionado:
            seguir = False

        enter_presionado = tecla[pygame.K_RETURN]

        screen.fill(c["NEGRO"])
        boton(screen, fuente, c, "JUGAR", 300,150,240,60, opcion_actual==0)
        boton(screen, fuente, c, "ESTADISTICAS", 300,250,240,60, opcion_actual==1)
        boton(screen, fuente, c, "CRÉDITOS", 300,350,240,60, opcion_actual==2)
        boton(screen, fuente, c, "SALIR", 300,450,240,60, opcion_actual==3)
        pygame.display.update()

    pygame.quit()
    return opcion_actual


# PANTALLA VICTORIA / DERROTA

def vict_der(screen, texto):
    c = color()
    fuente_titulo = pygame.font.SysFont(None, 120)
    fuente_texto = pygame.font.SysFont(None, 60)
    seguir = True

    while seguir:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                seguir = False

        tecla = pygame.key.get_pressed()

        screen.fill(c["NEGRO"])
        etiqueta1 = fuente_titulo.render(texto, True, c["BLANCO"])
        etiqueta2 = fuente_texto.render("Pulsa ENTER para continuar", True, c["BLANCO"])

        screen.blit(etiqueta1, (400 - etiqueta1.get_width()//2, 250))
        screen.blit(etiqueta2, (400 - etiqueta2.get_width()//2, 450))

        if tecla[pygame.K_RETURN]:
            seguir = False

        pygame.display.update()


# MOVIMIENTO DEL JUGADOR

def movimiento(rect, vel):
    teclas = pygame.key.get_pressed()

    viejox, viejoy = rect.x, rect.y

    if teclas[pygame.K_w] or teclas[pygame.K_UP]:    rect.y -= vel
    if teclas[pygame.K_s] or teclas[pygame.K_DOWN]:  rect.y += vel
    if teclas[pygame.K_a] or teclas[pygame.K_LEFT]:  rect.x -= vel
    if teclas[pygame.K_d] or teclas[pygame.K_RIGHT]: rect.x += vel

    rect.x = max(0, min(rect.x, 700))
    rect.y = max(0, min(rect.y, 700))

    return viejox, viejoy


# CREACIÓN DE ENTIDADES

def crear_jugador(x,y,img):
    return {"tipo": "jugador", "rect": img.get_rect(topleft=(x,y)), "vel":20, "img":img}

def crear_camion(x,y,direc,img):
    return {"tipo":"camion","rect":img.get_rect(topleft=(x,y)),"vel":20*direc,"img":img}

def crear_tren(x,y,direc,img):
    return {"tipo":"tren","rect":img.get_rect(topleft=(x,y)),"vel":60*direc,"img":img}

def crear_arbol(x,y,img):
    return {"tipo":"arbol","rect":img.get_rect(topleft=(x,y)),"vel":0,"img":img}

def crear_tronco(x,y,direc,img):
    return {"tipo":"tronco","rect":img.get_rect(topleft=(x,y)),"vel":20*direc,"img":img}

def crear_bandera(x,y,img):
    return {"tipo":"bandera","rect":img.get_rect(topleft=(x,y)),"vel":0,"img":img}


# COLISIÓN Y MOVIMIENTO

def colision(a, e):
    return a.colliderect(e["rect"])

def movimiento_entidades(e):
    e["rect"].x += e["vel"]

    if e["rect"].x > 900 and e["vel"] > 0:
        e["rect"].x = -200

    if e["rect"].x < -200 and e["vel"] < 0:
        e["rect"].x = 900


# BUCLE PRINCIPAL DEL JUEGO

def juego():
    pygame.init()
    screen = pantalla()
    pygame.display.set_caption("Crossy Road")

    c = color()
    entidades = []
    #ESCALAS EROMIX
    jugador_img = pygame.transform.scale(pygame.image.load("jugador.png"), (30,30))
    camion_img  = pygame.transform.scale(pygame.image.load("camion.png"), (100,100))
    tren_img    = pygame.transform.scale(pygame.image.load("tren.png"),   (100,100))
    tronco_img  = pygame.transform.scale(pygame.image.load("tronco.png"), (100,100))
    arbol_img   = pygame.transform.scale(pygame.image.load("arbol.png"),  (100,100))
    bandera_img = pygame.transform.scale(pygame.image.load("bandera.png"),(70,70))

    # ENTIDADES
    entidades.append(crear_jugador(20, 20, jugador_img))
    entidades.append(crear_camion(300,300,-1,camion_img))
    entidades.append(crear_tronco(0,100,1,tronco_img))
    entidades.append(crear_tronco(200,130,-1,tronco_img))
    entidades.append(crear_tren(300,500,1,tren_img))
    entidades.append(crear_arbol(200,400,arbol_img))
    entidades.append(crear_bandera(400,700,bandera_img))

    game_over = False

    

    
    while not game_over:
        pygame.time.delay(100)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                return False

        screen.fill(c["GRIS"])

        jugador = entidades[0]
        rect = jugador["rect"]
        vel = jugador["vel"]

        viejox, viejoy = movimiento(rect, vel)

        # MOVER Y COLISIONAR
        for e in entidades:
            movimiento_entidades(e)

            if colision(rect, e):
                if e["tipo"] in ("camion", "tren"):
                    vict_der(screen, "GAME OVER")
                    return True

                if e["tipo"] == "arbol":
                    rect.x, rect.y = viejox, viejoy

                if e["tipo"] == "tronco":
                    rect.x += e["vel"]

                if e["tipo"] == "bandera":
                    vict_der(screen, "VICTORIA")
                    return True

            # Agua invisible
            if e["tipo"] == "tronco":
                if not colision(rect, e) and e["rect"].y <= rect.y <= e["rect"].y + e["rect"].height:
                    vict_der(screen, "GAME OVER")
                    return True

        # DIBUJAR ENTIDADES
        for e in entidades:
            screen.blit(e["img"], e["rect"])

        pygame.display.update()

    return True




def main():
    seguir = True
    while seguir:
        op = menu()
        if op == 0:
            seguir = juego()
        else:
            seguir = False

main()

